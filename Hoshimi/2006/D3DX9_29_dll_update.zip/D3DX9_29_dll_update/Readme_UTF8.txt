﻿|---------------------------------------------------|
|                 www.ThreeLights.de                |
|---------------------------------------------------|
|                                                   |
| This file contains a installer which installs the |
| D3DX9_29.dll.                                     |
|                                                   |
| It uses the Microsofts own directx setup to       |
| ensure that the files are installed/updated       |
| properly.                                         |
|                                                   |
| In the directory license you will find a copy of  |
| Microsofts statement according redistributing     |
| DirectX. This is the only legal way to obtain all |
| the D3DX9_xx.dll's available so far. Please don't |
| blame Microsoft for this. It gives us developers  |
| the advantage to have smaller executable files    |
| for our programs and enhances the security of     |
| your system, because it allows Microsoft to       |
| provide Bug-Fixes for your D3DX-Library.          |
| (I think)                                         |
|                                                   |
| This updates adds/updates following files to your |
| EXISTING DirectX 9 installation:                  |
|                                                   |
| d3dx9_29.dll (February 2006)                      |
|                                                   |
|---------------------------------------------------|
|   Matthias Langer aka. T3L (t3l@threelights.de)   |
|---------------------------------------------------|

Shanghai 2006-03-13 by T3L
